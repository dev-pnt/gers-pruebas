<?php
// created: 2012-10-31 00:35:40
$mod_strings = array (
  'LBL_ESCALAFON' => 'Escalafón',
  'LBL_MILESTONE_FLAG' => '¿Tiene entregable?',
  'LBL_ANTICIPOS' => 'Anticipos',
  'LBL_PROJECT_NAME' => 'Proyecto',
);